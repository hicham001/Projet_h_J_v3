package com.sqli.echallenge.bap.dao;

import com.sqli.echallenge.bap.model.SujetModel;

public interface ISujetDao extends IGenericDao<SujetModel>{

}
