package com.sqli.echallenge.bap.dao;

import com.sqli.echallenge.bap.model.DescriptionObjModel;

public class IDescriptionObjDaoImpl extends GenericDaoImpl<DescriptionObjModel> implements IDescriptionObjDao{

	public IDescriptionObjDaoImpl() {
		super(DescriptionObjModel.class);
		// TODO Auto-generated constructor stub
	}

}
