package com.sqli.echallenge.bap.dao;


import com.sqli.echallenge.bap.model.ResultatPoidsModel;

public class IResultatPoidsDaoImpl extends GenericDaoImpl<ResultatPoidsModel> implements IResultatPoidsDao{

	public IResultatPoidsDaoImpl() {
		super(ResultatPoidsModel.class);
	}


}
