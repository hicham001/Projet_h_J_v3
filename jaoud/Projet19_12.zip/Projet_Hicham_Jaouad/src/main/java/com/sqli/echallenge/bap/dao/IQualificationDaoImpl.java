package com.sqli.echallenge.bap.dao;

import com.sqli.echallenge.bap.model.QualificationModel;

public class IQualificationDaoImpl extends GenericDaoImpl<QualificationModel> implements IQualificationDao{

	public IQualificationDaoImpl() {
		super(QualificationModel.class);
		// TODO Auto-generated constructor stub
	}

}
