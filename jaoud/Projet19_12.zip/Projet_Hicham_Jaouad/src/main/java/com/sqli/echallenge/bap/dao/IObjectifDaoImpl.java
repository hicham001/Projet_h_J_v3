package com.sqli.echallenge.bap.dao;

import com.sqli.echallenge.bap.model.ObjectifModel;

public class IObjectifDaoImpl extends GenericDaoImpl<ObjectifModel> implements IObjectifDao{

	public IObjectifDaoImpl() {
		super(ObjectifModel.class);
	}

}
