package com.sqli.echallenge.bap.dao;

import com.sqli.echallenge.bap.model.FeedbackModel;

public interface IFeedbackDao extends IGenericDao<FeedbackModel> {
	
}
