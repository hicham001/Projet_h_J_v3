package com.sqli.echallenge.bap.dao;

import com.sqli.echallenge.bap.model.QualificationModel;

public interface IQualificationDao extends IGenericDao<QualificationModel>{

}
