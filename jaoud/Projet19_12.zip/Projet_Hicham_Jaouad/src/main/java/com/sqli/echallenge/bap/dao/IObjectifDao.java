package com.sqli.echallenge.bap.dao;


import com.sqli.echallenge.bap.model.ObjectifModel;

public interface IObjectifDao extends IGenericDao<ObjectifModel>{

}
