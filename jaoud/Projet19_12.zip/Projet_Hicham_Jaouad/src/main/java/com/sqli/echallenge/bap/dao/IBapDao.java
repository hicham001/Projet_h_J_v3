package com.sqli.echallenge.bap.dao;

import com.sqli.echallenge.bap.model.BAPModel;

public interface IBapDao extends IGenericDao<BAPModel>{
	

}
