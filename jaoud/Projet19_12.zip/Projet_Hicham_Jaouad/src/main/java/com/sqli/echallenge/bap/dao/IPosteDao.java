package com.sqli.echallenge.bap.dao;

import com.sqli.echallenge.bap.model.PosteModel;

public interface IPosteDao extends IGenericDao<PosteModel> {

}
