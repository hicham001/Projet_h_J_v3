package com.sqli.echallenge.bap.dao;

import com.sqli.echallenge.bap.model.ReponseObjModel;

public class IReponseObjDaoImpl extends GenericDaoImpl<ReponseObjModel> implements IReponseObjDao{

	public IReponseObjDaoImpl() {
		super(ReponseObjModel.class);
	}

}
