package com.sqli.echallenge.bap.web.dto;

import java.sql.Date;

public class HistoriqueFeedbackDto extends FeedbackDto{
	private Date dateHisorisation;
	private String intitule;

}
