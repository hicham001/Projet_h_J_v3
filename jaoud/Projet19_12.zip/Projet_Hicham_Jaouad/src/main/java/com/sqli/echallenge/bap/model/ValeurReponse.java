package com.sqli.echallenge.bap.model;

public enum ValeurReponse {

	Rejeter,
    Valider
}
