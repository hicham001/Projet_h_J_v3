package com.sqli.echallenge.bap.web.dto;

import java.sql.Date;

public class HistoriqueBAPDto extends BAPDto {
	private Date datHisorisation;
	private String intitule;
	

}
