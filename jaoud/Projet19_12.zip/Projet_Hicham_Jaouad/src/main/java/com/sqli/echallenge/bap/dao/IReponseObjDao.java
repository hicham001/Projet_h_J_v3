package com.sqli.echallenge.bap.dao;

import com.sqli.echallenge.bap.model.ReponseObjModel;

public interface IReponseObjDao extends IGenericDao<ReponseObjModel>{

}
